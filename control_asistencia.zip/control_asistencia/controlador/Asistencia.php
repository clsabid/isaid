<?php
// controlador/Asistencia.php
require_once("../admin/config/global.php");
date_default_timezone_set('America/Mexico_City');

require_once("../modelos/Asistencia.php");

// Mostrar errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$asistencia = new Asistencia();

$fecha = date("Y-m-d");
$hora = date("H:i:s");

switch ($_GET["op"]) {

    case 'registrar':
        $codigo_persona = $_REQUEST['codigo'];
        $persona = $asistencia->verificarCodigo_persona($codigo_persona);

        if ($persona && isset($persona['id'])) {
            $asistencia_actual = $asistencia->buscar_asistencia($codigo_persona, $fecha);

            $tipo = (!empty($asistencia_actual) && $asistencia_actual['tipo'] == 'Entrada') ? 'Salida' : 'Entrada';
            $rspsta = $asistencia->registrar_asistencia($persona['id'], $hora, $fecha, $tipo);

            echo $rspsta ? $tipo . ' registrada' : 'No se pudo registrar su ' . $tipo;
        } else {
            echo 'No hay empleado registrado con este código';
        }
        break;
}
?>

