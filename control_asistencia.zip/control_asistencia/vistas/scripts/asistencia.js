// Crea un nuevo objeto Scanner de Instascan con las configuraciones especificadas
var scanner = new Instascan.Scanner({
    continuos: true,
    video: document.getElementById('preview'), // Elemento de video para mostrar la vista previa del escáner
    mirror: false, // No se refleja la imagen en el escáner
    captureImage: false, // No se captura la imagen
    backgroundScan: false, // No se escanea en segundo plano
    refractoryPeriod: 5000, // Periodo refractario de 5 segundos
    scanPeriod: 5 // Periodo de escaneo de 5 milisegundos
});

// Agrega un evento 'scan' al escáner que se activa cuando se escanea un código
scanner.addListener('scan', function(content) {
    // Realiza una solicitud POST al script PHP para registrar la asistencia con el código escaneado
    $.post("../controlador/Asistencia.php?op=registrar", { "codigo": content }, function(data) {
        // Muestra una notificación de éxito utilizando la biblioteca SweetAlert
        Swal.fire({
            title: "Asistencia",
            text: data,
            icon: "success"
        });
    });
});

// Función para iniciar la cámara y comenzar a escanear códigos QR
function iniciaCamara() {
    // Obtiene las cámaras disponibles y comienza a escanear utilizando la última cámara encontrada
    Instascan.Camera.getCameras().then(function(cameras) {
        if (cameras.length > 0) {
            scanner.start(cameras[cameras.length - 1]); // Comienza a escanear con la primera cámara
        } else {
            alert('No se encontró una cámara disponible');
            console.error('No se encontró una cámara disponible.');
        }
    }).catch(function(e) {
        console.error(e);
    });
}

// Función para detener el escaneo y apagar la cámara
function apagaCamara() {
    scanner.stop();
}