<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript" src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
    <link rel="stylesheet" href="../admin/public/css/bootstrap.min.css">
    <link rel="stylesheet" href="../admin/public/css/font-awesome.css">

    <link rel="stylesheet" href="../admin/public/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../admin/public/css/blue.css">
    <link rel="shortcut icon" href="../admin/public/img/favicon.ico">
    <link rel="stylesheet" href="../admin/public/css/_all-skins.min.css">
    <style>
        #preview {
            width: 80;
            height: 15rem;
            margin: auto;
        }

        .main-footer {
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
    <title>Asistencia</title>
</head>
<body class="hold-transition skin-blue layout-top-nav">
    <header class="main-header">
        <nav class="navbar navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a href="../../index2.html" class="navbar-brand"><b>SIS</b>ASISTENCIA</a>
                    <button type="Button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>

                <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="../admin/">ADMIN</a></li>
                    </ul>
                </div>
                </div>
            </nav>
    </header>

    <div class="content-wrapper">
        <div class="container">
            <section class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Registro de Asistencias</h3>
                            </div>
                            <div class="box-body">
                                <div class="col-lg-12">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <label for="">Cámara</label>
                                        <div id="camara">
                                            <video id="preview" class="border border-primary"></video>
                                            <div id="cuadro"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <button type="button" id="btnIngreso" onclick="iniciaCamara()" class="btn btn-success">Iniciar Cámara</button>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <button type="button" id="btnSalida" onclick="apagaCamara()" class="btn btn-warning">Apagar Cámara</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 8.0.1
        </div>
        <strong>Copyright &copy; 2023-2024 <a target="_blank" href="https://www.compartiendocodigos.com">CompartiendoCódigos</a></strong> Todos los derechos reservados.
    </footer>

    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <script type="text/javascript" src="scripts/asistencia.js?<?php echo time(); ?>"></script>

</body>
</html>