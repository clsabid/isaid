<?php

require_once("../admin/config/conexion.php");

class Asistencia 
{
    public function __construct() {}

    public function verificarCodigo_persona($codigo_persona) 
    {
        $sql = "SELECT * FROM empleado WHERE codigo = '$codigo_persona'";
        return ejecutarConsultaSimpleFila($sql);
    }

    public function verificarEmpleadoPorId($id)
    {
        $sql = "SELECT * FROM empleado WHERE id = '$id'";
        return ejecutarConsultaSimpleFila($sql);
    }

    public function buscar_asistencia($codigo_persona, $fecha)
    {
        $sql = "SELECT a.id, a.fecha, a.hora, a.tipo
                FROM asistencia a 
                INNER JOIN empleado e ON a.codigo = e.codigo
                WHERE e.codigo = '$codigo_persona' AND a.fecha = '$fecha'";
        return ejecutarConsultaSimpleFila($sql);
    }

    public function registrar_asistencia($id_empleado, $hora, $fecha, $tipo) 
    {
        $persona = $this->verificarEmpleadoPorId($id_empleado);

        $codigo = $persona['codigo'];
        $nombre_completo = $persona['nombre'] . ' ' . $persona['apellidos'];

        $sql = "INSERT INTO asistencia (codigo, empleado, hora, fecha, tipo) 
                VALUES ('$codigo', '$nombre_completo', '$hora', '$fecha', '$tipo')";

        return ejecutarConsulta($sql);
    }
}
