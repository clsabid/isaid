var tabla;
var tabla_asistencia; // Usaremos esta variable si la tabla de asistencia se maneja por separado de 'tabla'

function init() {
    listar(); // Para listar la asistencia existente al cargar la página

    // Manejador para ocultar el foco cuando un modal de Bootstrap se oculta
    $(document).on('hidden.bs.modal', '.modal', function () {
        $('body').removeAttr('aria-hidden');
        if (document.activeElement) {
            document.activeElement.blur();
        }
    });

    // Si estás usando un tema de AdminLTE o similar que envuelve el body/content
    $(document).on('hidden.bs.modal', function () {
        $('body > .wrapper, body > .content-wrapper').removeAttr('aria-hidden');
    });

    // =========================================================================
    // ✅ EJEMPLO DE CÓMO INICIAR EL REGISTRO DE ASISTENCIA (AJUSTA SEGÚN TU HTML)
    // =========================================================================
    // Si tienes un formulario con un campo para el código y un botón de "Registrar Entrada" y otro de "Registrar Salida"
    // Asegúrate de que el ID del formulario y los botones/campos coincidan con tu HTML.

    $("#form_asistencia").on("submit", function(e){
        e.preventDefault();
        var codigo = $("#inputCodigoAsistencia").val(); // ID de tu campo de texto para el código
        var tipo = $('input[name="tipo_asistencia"]:checked').val(); // Si tienes radio buttons para 'entrada'/'salida'

        if (codigo && tipo) {
            registrarAsistenciaPorCodigo(codigo, tipo);
        } else {
            bootbox.alert("Por favor, introduce el código y selecciona el tipo de asistencia (entrada/salida).");
        }
        $("#inputCodigoAsistencia").val(""); // Limpia el campo después de registrar
    });

    // Si tienes botones separados para entrada y salida:
    $("#btnRegistrarEntrada").on("click", function(){
        var codigo = $("#inputCodigoAsistencia").val();
        if (codigo) {
            registrarAsistenciaPorCodigo(codigo, 'entrada');
        } else {
            bootbox.alert("Por favor, introduce el código para registrar la entrada.");
        }
        $("#inputCodigoAsistencia").val("");
    });

    $("#btnRegistrarSalida").on("click", function(){
        var codigo = $("#inputCodigoAsistencia").val();
        if (codigo) {
            registrarAsistenciaPorCodigo(codigo, 'salida');
        } else {
            bootbox.alert("Por favor, introduce el código para registrar la salida.");
        }
        $("#inputCodigoAsistencia").val("");
    });
    // =========================================================================
}

// Función para registrar la asistencia del USUARIO por su código
function registrarAsistenciaPorCodigo(codigo, tipo) { // 'tipo' sería 'entrada' o 'salida'
    $.ajax({
        url: "../controlador/Asistencia.php?op=registrar", // Llama a la nueva operación en el controlador
        type: "POST",
        data: { codigo: codigo, tipo: tipo }, // Envía el código y el tipo de asistencia
        dataType: "json",
        success: function(response) {
            bootbox.alert({
                message: response.message,
                callback: function() {
                    if (document.activeElement) {
                        document.activeElement.blur();
                    }
                    $('body').removeAttr('aria-hidden');
                    $('body > .wrapper, body > .content-wrapper').removeAttr('aria-hidden');
                }
            });
            // Recargar tabla de asistencia si existe
            if (typeof tabla !== 'undefined') { // Asumiendo que 'tabla' es la variable de tu DataTable de asistencia
                tabla.ajax.reload(null, false); // false para mantener la paginación actual
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("Error en la solicitud AJAX de registro de asistencia:", textStatus, errorThrown, jqXHR.responseText);
            bootbox.alert({
                message: "Hubo un error al registrar la asistencia. Revise la consola para más detalles.",
                callback: function() {
                    if (document.activeElement) {
                        document.activeElement.blur();
                    }
                    $('body').removeAttr('aria-hidden');
                    $('body > .wrapper, body > .content-wrapper').removeAttr('aria-hidden');
                }
            });
        }
    });
}


function listar() {
    tabla = $('#tbllistado').dataTable({
        "aProcessing": true,
        "aServerSide": true,
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5', 'excelHtml5', 'csvHtml5', 'pdf'
        ],
        "ajax": {
            url: '../controlador/Asistencia.php?op=listar',
            type: "get",
            dataType: "json",
            error: function(e) {
                console.log(e.responseText);
            }
        },
        "bDestroy": true,
        "iDisplayLength": 10,
        "order": [[0, "desc"]]
    }).DataTable();
    // Guardar la instancia de DataTable para usarla en `registrarAsistenciaPorCodigo` si es la misma tabla
    tabla_asistencia = tabla;
}

init();