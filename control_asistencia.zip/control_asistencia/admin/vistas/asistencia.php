<?php 
ob_start();
session_start();

if(!isset($_SESSION['nombre'])){
    header("Location: login.html");
    exit();
} else {
    require 'header.php';
?>
<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">

                    <div class="box-header with-border">
                        <h1 class="box-title">Lista de asistencias</h1>
                    </div>

                    <div class="panel-body table-responsive" id="listadoregistros">
                        <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>codigo</th>
                                    <th>empleado</th>
                                    <th>hora</th>
                                    <th>tipo</th>
                                    <th>fecha</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>codigo</th>
                                    <th>empleado</th>
                                    <th>hora</th>
                                    <th>tipo</th>
                                    <th>fecha</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </section>
</div>

<?php 
    require 'footer.php'; 
}
ob_end_flush();
?>
<script src="scripts/asistencia.js"></script>
