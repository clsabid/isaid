<?php
// Incluye el archivo global.php que contiene las constantes de configuración de la base de datos
require_once("global.php");
// LÍNEA DE DEPURACIÓN: Añade esto justo después del require_once("global.php");
// error_log("global.php fue incluido en conexion.php"); // Puedes descomentar esto si quieres el log

// Establece la conexión con la base de datos utilizando las constantes definidas en global.php
$conexion = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// LÍNEA DE DEPURACIÓN: Añade esto justo después de intentar la conexión
if ($conexion->connect_error) {
    // Si la conexión falla, el error_log registrará el detalle.
    // printf("Ups parece que falló en la conexion con la base de datos: %s\n", mysqli_connect_error()); // Esta línea puede ser la que genera el <br />
    error_log("Error de conexión a la base de datos: " . $conexion->connect_error);
    // Para que no se quede pendiente, podemos enviar un JSON de error y salir.
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión a la base de datos: ' . $conexion->connect_error]);
    exit(); // Es crucial salir para evitar más errores o colgar el script
} else {
    // error_log("Conexión a la base de datos exitosa."); // Puedes descomentar esto si quieres el log
}

// Establece el conjunto de caracteres para la conexión
// ✅ ATENCIÓN A ESTA LÍNEA (23): Asegúrate de que no haya espacios invisibles o caracteres extraños
mysqli_query($conexion, 'SET NAMES "' . DB_ENCODE . '"');

// Comprueba si hay errores en la conexión después de la conexión inicial
// Esta parte puede ser redundante si el if ($conexion->connect_error) ya lo maneja.
// Pero la dejamos por si acaso, aunque el exit() en la conexión fallida es mejor.
if (mysqli_connect_errno()) {
    // printf("Ups parece que falló en la conexion con la base de datos: %s\n", mysqli_connect_error()); // Esta línea puede generar HTML si no estamos en modo JSON
    error_log("Ups parece que falló en la conexion con la base de datos (segundo check): " . mysqli_connect_error());
    echo json_encode(['status' => 'error', 'message' => 'Fallo en la conexión DB.']);
    exit();
}

// Verifica si la función ejecutarConsulta no está definida para evitar conflictos de redefinición
if (!function_exists('ejecutarConsulta')) {
    // Define la función ejecutarConsulta que ejecuta consultas SQL y devuelve el resultado
    function ejecutarConsulta($sql) {
        global $conexion;
        $query = $conexion->query($sql);
        if (is_bool($query)) {
            return $query;
        }
        return $query;
    }

    // Define la función ejecutarConsultaSimpleFila que ejecuta consultas SQL y devuelve una fila de resultados
    function ejecutarConsultaSimpleFila($sql) {
        global $conexion;
        $query = $conexion->query($sql);
        if ($query) {
            $row = $query->fetch_assoc();
            $query->free();
            return $row;
        }
        return false;
    }

    // Define la función ejecutarConsulta_retornarID que ejecuta consultas SQL y devuelve el ID insertado
    function ejecutarConsulta_retornarID($sql) {
        global $conexion;
        $conexion->query($sql);
        return $conexion->insert_id;
    }

    // Define la función limpiarCadena que limpia una cadena para evitar inyecciones SQL y XSS
    function limpiarCadena($str) {
        global $conexion;
        $str = mysqli_real_escape_string($conexion, trim($str));
        return htmlspecialchars($str);
    }
}
?>