<?php
// ✅ Mostrar errores PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Requerimos el modelo correcto para la tabla 'asistencia' de empleados
require_once "../modelos/Asistencia.php"; 

// Instanciamos el modelo Asistencia (para empleados)
$asistencia = new Asistencia(); 

// Asegúrate de que la función limpiarCadena() esté disponible aquí.
// Si está en config/conexion.php o un archivo global, no la declares aquí.
// Ejemplo: si tu config/conexion.php ya la define, esto no es necesario.
// Si no la tienes en ningún lado, puedes definirla aquí (o mejor en un archivo de utilidades).
/*
if (!function_exists('limpiarCadena')) {
    function limpiarCadena($cadena){
        global $conexion; // Si usas la conexión global directamente en esta función
        $cadena = htmlspecialchars(trim($cadena), ENT_QUOTES, 'UTF-8');
        // Si utilizas consultas preparadas, no necesitas real_escape_string aquí.
        // Si no utilizas consultas preparadas, DESCOMENTA la siguiente línea para seguridad:
        // $cadena = $conexion->real_escape_string($cadena);
        return $cadena;
    }
}
*/

$op = isset($_GET["op"]) ? limpiarCadena($_GET["op"]) : ""; 

switch ($op) {
    case "registrar": // Registrar asistencia desde QR para EMPLEADOS (tabla 'asistencia')
        $codigo_asistencia = isset($_POST["codigo"]) ? limpiarCadena($_POST["codigo"]) : "";
        $tipo_asistencia = isset($_POST["tipo"]) ? limpiarCadena($_POST["tipo"]) : ""; 

        if (empty($codigo_asistencia)) {
            echo json_encode(['status' => 'error', 'message' => 'Código no proporcionado.']);
            exit();
        }

        // Buscar el empleado por código usando el método del modelo Asistencia
        $empleado_data = $asistencia->buscarUsuarioPorCodigo($codigo_asistencia); 

        if ($empleado_data) {
            $id_empleado = $empleado_data['id'];
            $nombre_completo_empleado = $empleado_data['nombre'] . ' ' . $empleado_data['apellidos'];

            // Registrar asistencia. El método en el modelo decide si es entrada/salida.
            $rpta = $asistencia->registrarAsistencia($id_empleado, $codigo_asistencia);

            if ($rpta) {
                echo json_encode(['status' => 'success', 'message' => 'Asistencia de ' . $nombre_completo_empleado . ' registrada correctamente.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error al registrar asistencia o ya se registraron entrada y salida para hoy.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No hay empleado registrado con este código: ' . $codigo_asistencia]);
        }
        break;

    case "listar": // Listar asistencias de EMPLEADOS (tabla 'asistencia')
        $rpta = $asistencia->listar(); 
        $data = array();

        while ($reg = $rpta->fetch_object()) {
            // Convertir a minúsculas y quitar espacios para una comparación robusta
            $tipo_limpio = strtolower(trim($reg->tipo)); 

            $data[] = array(
                "0" => $reg->id, 
                "1" => $reg->codigo,
                "2" => $reg->empleado, // Usamos directamente la columna 'empleado'
                "3" => $reg->hora,
                // --- CORRECCIÓN CLAVE AQUÍ: Lógica de color y texto ---
                "4" => $tipo_limpio == "entrada" ? '<span class="label bg-green">entrada</span>' : '<span class="label bg-orange">salida</span>',
                // --- FIN CORRECCIÓN ---
                "5" => $reg->fecha
            );
        }

        $results = array(
            "sEcho" => 1,
            "iTotalRecords" => count($data),
            "iTotalDisplayRecords" => count($data),
            "aaData" => $data
        );

        echo json_encode($results);
        break;

    case "listar_asistencia": // Reporte de asistencias de EMPLEADOS
        $fecha_inicio = isset($_REQUEST["fecha_inicio"]) ? limpiarCadena($_REQUEST["fecha_inicio"]) : "";
        $fecha_fin = isset($_REQUEST["fecha_fin"]) ? limpiarCadena($_REQUEST["fecha_fin"]) : "";
        $codigo_o_id_usuario = isset($_REQUEST["empleado_id"]) ? limpiarCadena($_REQUEST["empleado_id"]) : "";

        $rpta = $asistencia->listar_reporte($fecha_inicio, $fecha_fin, $codigo_o_id_usuario);

        $data = array();
        $item = 0; 
        while ($reg = $rpta->fetch_object()) {
            // Convertir a minúsculas y quitar espacios para una comparación robusta
            $tipo_limpio = strtolower(trim($reg->tipo));

            $data[] = array(
                "0" => $item + 1, 
                "1" => $reg->codigo,
                "2" => $reg->empleado, // Usamos directamente la columna 'empleado'
                "3" => $reg->fecha,
                "4" => $reg->hora,
                // --- CORRECCIÓN CLAVE AQUÍ: Lógica de color y texto ---
                "5" => $tipo_limpio == "entrada" ? '<span class="label bg-green">entrada</span>' : '<span class="label bg-orange">salida</span>'
                // --- FIN CORRECCIÓN ---
            );
            $item++;
        }

        $results = array(
            "sEcho" => 1,
            "iTotalRecords" => count($data),
            "iTotalDisplayRecords" => count($data),
            "aaData" => $data
        );

        echo json_encode($results);
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Operación no válida']);
        break;
}
?>