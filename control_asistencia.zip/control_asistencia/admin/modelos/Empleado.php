<?php
// Incluir la conexión a la base de datos
require "../config/conexion.php"; // Asumiendo que conexion.php define ejecutarConsulta y ejecutarConsultaSimpleFila

class Empleado
{
    // Constructor de la clase Empleado
    public function __construct()
    {
    }

    // Método para insertar un nuevo registro de empleado
    public function insertar($nombre, $apellidos, $documento_numero, $telefono, $codigo)
    {
        $sql = "INSERT INTO empleado (nombre, apellidos, documento_numero, telefono, codigo)
        VALUES ('$nombre', '$apellidos', '$documento_numero', '$telefono', '$codigo')";
        return ejecutarConsulta($sql);
    }

    // Método para editar un registro de empleado existente
    public function editar($empleado_id, $nombre, $apellidos, $documento_numero, $telefono, $codigo)
    {
        $sql = "UPDATE empleado SET nombre='$nombre', apellidos='$apellidos', documento_numero='$documento_numero',
        telefono='$telefono', codigo='$codigo' WHERE id='$empleado_id'"; // ✅ Correcto: usa 'id'
        return ejecutarConsulta($sql);
    }

    // Método para eliminar un registro de empleado
    public function eliminar($empleado_id)
    {
        $sql = "DELETE FROM empleado WHERE id='$empleado_id'"; // ✅ Correcto: usa 'id'
        return ejecutarConsulta($sql);
    }

    // Método para mostrar los detalles de un empleado específico
    public function mostrar($id)
    {
        $sql = "SELECT * FROM empleado WHERE id='$id'"; // ✅ Correcto: usa 'id'
        return ejecutarConsultaSimpleFila($sql);
    }

    // Método para listar todos los registros de empleados
    public function listar()
    {
        $sql = "SELECT * FROM empleado";
        return ejecutarConsulta($sql);
    }

    // Método para listar y mostrar en un select los registros de empleados
    public function select()
    {
        $sql = "SELECT * FROM empleado";
        return ejecutarConsulta($sql);
    }
}