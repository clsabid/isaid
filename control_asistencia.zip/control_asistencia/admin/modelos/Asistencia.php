<?php
require_once __DIR__ . '/../config/conexion.php';
// Asegúrate de que el modelo Empleado.php exista y contenga la lógica para la tabla 'empleado'.
// Lo necesitamos para buscar el nombre del empleado al registrar la asistencia.
require_once __DIR__ . '/../modelos/Empleado.php'; // Incluir Empleado.php

class Asistencia
{
    public function __construct() {}

    public function registrarAsistencia($id_usuario, $codigo)
    {
        $fecha = date("Y-m-d");
        $hora = date("H:i:s");

        // Revisar si ya hay registros hoy para este usuario
        $sql_check = "SELECT tipo FROM asistencia 
                      WHERE id_usuario = '$id_usuario' AND fecha = '$fecha' 
                      ORDER BY hora ASC";
        $result = ejecutarConsulta($sql_check);

        $tipos = [];
        if ($result) { // Asegurarse de que la consulta de verificación se ejecutó con éxito
            while ($row = $result->fetch_assoc()) {
                $tipos[] = $row['tipo'];
            }
        }

        // Determinar si es entrada o salida
        if (!in_array('entrada', $tipos)) {
            $tipo = 'entrada';
        } elseif (!in_array('salida', $tipos)) {
            $tipo = 'salida';
        } else {
            // Ya tiene entrada y salida hoy, no se puede registrar más
            return false;
        }

        // --- Obtener el nombre completo del empleado para la columna 'empleado' en tabla 'asistencia' ---
        $empleadoModel = new Empleado(); // Instanciar el modelo Empleado
        // Asumiendo que Empleado.php tiene un método 'mostrar' o 'obtenerPorId' que busca por ID
        $empleado_data = $empleadoModel->mostrar($id_usuario); 
        $nombre_completo_empleado = 'Desconocido'; // Valor por defecto
        if ($empleado_data && isset($empleado_data['nombre']) && isset($empleado_data['apellidos'])) {
            $nombre_completo_empleado = $empleado_data['nombre'] . ' ' . $empleado_data['apellidos'];
        }
        // --- Fin: Obtener el nombre completo del empleado ---

        // Insertar el registro de asistencia
        $sql_insert = "INSERT INTO asistencia (id_usuario, codigo, empleado, fecha, hora, tipo) 
                       VALUES ('$id_usuario', '$codigo', '$nombre_completo_empleado', '$fecha', '$hora', '$tipo')";
        
        // Depuración: Puedes eliminar estas líneas después de verificar que funciona
        error_log("DEBUG: SQL de inserción en Asistencia.php: " . $sql_insert);
        $insert_result = ejecutarConsulta($sql_insert);
        if (!$insert_result) {
            global $conexion; // Acceder a la conexión si está disponible globalmente
            error_log("DEBUG: Error al insertar asistencia: " . $conexion->error);
        }
        return $insert_result;
    }

    public function buscarUsuarioPorCodigo($codigo)
    {
        // Esta función debe buscar en la tabla 'empleado' para obtener los datos del empleado
        // que se va a registrar. Asumo que tu tabla de empleados se llama 'empleado'.
        $sql = "SELECT id, nombre, apellidos, documento_numero, telefono, codigo FROM empleado WHERE codigo = '$codigo'";
        error_log("DEBUG: SQL de buscarUsuarioPorCodigo en Asistencia.php: " . $sql); // Depuración
        $result = ejecutarConsultaSimpleFila($sql);
        if (!$result) {
            global $conexion;
            error_log("DEBUG: Error en buscarUsuarioPorCodigo: " . $conexion->error);
        }
        return $result;
    }

    public function listar()
    {
        // Seleccionamos directamente la columna 'empleado' de la tabla 'asistencia'
        // ya que la imagen de tu DB muestra que el nombre del empleado ya está ahí.
        $sql = "SELECT
                    id,
                    codigo,
                    empleado,      -- Seleccionamos directamente la columna 'empleado'
                    fecha,
                    hora,
                    tipo
                FROM asistencia";
        
        error_log("DEBUG: SQL de listar en Asistencia.php: " . $sql); // Depuración
        $resultado = ejecutarConsulta($sql);
        if (!$resultado) {
            global $conexion;
            error_log("DEBUG: Error al ejecutar consulta en listar(): " . $conexion->error);
            return false;
        }
        error_log("DEBUG: Número de filas devueltas por listar(): " . $resultado->num_rows); // Depuración

        return $resultado;
    }

    public function listar_reporte($fecha_inicio, $fecha_fin, $id_usuario_o_codigo)
    {
        // El reporte también debe usar la columna 'empleado' directamente.
        $sql = "SELECT
                    id,
                    codigo,
                    empleado,      -- Seleccionamos directamente la columna 'empleado'
                    fecha,
                    hora,
                    tipo
                FROM asistencia 
                WHERE fecha >= '$fecha_inicio' AND fecha <= '$fecha_fin'";

        if (!empty($id_usuario_o_codigo) && $id_usuario_o_codigo !== "all") {
            // Aquí, si 'empleado_id' es un ID, busca por id_usuario. Si es código, por código.
            if (is_numeric($id_usuario_o_codigo)) {
                $sql .= " AND id_usuario = '$id_usuario_o_codigo'"; // Si $id_usuario es el ID del empleado
            } else {
                $sql .= " AND codigo = '$id_usuario_o_codigo'"; // Si $codigo es el código del empleado en tabla asistencia
            }
        }
        error_log("DEBUG: SQL de listar_reporte en Asistencia.php: " . $sql); // Depuración
        $result = ejecutarConsulta($sql);
        if (!$result) {
            global $conexion;
            error_log("DEBUG: Error en listar_reporte: " . $conexion->error);
        }
        return $result;
    }
}
?>